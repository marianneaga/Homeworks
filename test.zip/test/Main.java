package homeworks.test;

public class Main {
    public static void main(String[] args) {
        Shape shape = new Circle(5);
        Shape shape1 = new Rectangle(5, 6);

        shape.printSurface();
        shape1.printPerimeter();
        shape.draw();
        shape1.draw();

        Tool t1 = new Tool();

        t1.addShape(shape1);
        t1.addShape(shape);
        t1.calculateTotalSumPerimeter();
        t1.calculateTotalSumSurface();
    }


}
