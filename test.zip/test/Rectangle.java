package homeworks.test;

public class Rectangle implements Shape{
    private double x, y, perimeter, surface;

    public Rectangle(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getPerimeter() {
        return x*2 + y*2;
    }

    public double getSurface() {
        return x*y;
    }

    @Override
    public void printPerimeter() {
        System.out.println("Perimeter is " + getPerimeter());
    }

    @Override
    public void printSurface() {
        System.out.println("Surface is " + getSurface());

    }

    @Override
    public void draw() {
        System.out.println("Drawing Rectangle with Surface: " + getSurface() + " and Perimeter: " + getPerimeter());

    }
}
