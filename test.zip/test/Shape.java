package homeworks.test;

public interface Shape {

    double getPerimeter();
    double getSurface();

    void printPerimeter();

    void printSurface();

    void draw();
}
