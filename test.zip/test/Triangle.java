package homeworks.test;

public class Triangle implements Shape{
    public Triangle(double lat1, double base, double lat2, double height) {
        this.lat1 = lat1;
        this.base = base;
        this.lat2 = lat2;
        this.height = height;
    }

    private double lat1, base, lat2, height, perimeter, surface;

    public double getPerimeter() {
        return lat1 + lat2 + base;
    }

    public double getSurface() {
        return base *0.5 * height;
    }

    @Override
    public void printPerimeter() {
        System.out.println("Perimeter = " + getPerimeter());

    }

    @Override
    public void printSurface() {
        System.out.println("Surface = " + getSurface());

    }

    @Override
    public void draw() {
        System.out.println("Drawing Triangle with Surface: " + getSurface() + " and Perimeter: " + getPerimeter());

    }
}
