package homeworks.test;

public class Circle implements Shape{
    private double r;

    public Circle(double r) {
        this.r = r;
    }

    public double getPerimeter() {
        return 2*Math.PI*r;
    }


    public double getSurface() {
        return Math.PI * Math.pow(r,2);
    }

    @Override
    public void printPerimeter() {
        System.out.println("Perimeter is " + getPerimeter());

    }

    @Override
    public void printSurface() {
        System.out.println("Surface is " + getSurface());

    }

    @Override
    public void draw() {
        System.out.println("Drawing Circle with Surface: " + getSurface() + " and Perimeter: " + getPerimeter());
    }
}
