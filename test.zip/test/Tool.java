package homeworks.test;

import java.util.ArrayList;
import java.util.List;

public class Tool {
    List<Shape> shapes;
    private double sumPerimeter;
    private double sumSurface;

    public Tool() {
        shapes = new ArrayList<>();
    }

    void addShape(Shape shape) {
        shapes.add(shape);
    }


    void calculateTotalSumPerimeter() {
        System.out.println("Total perimeter sum is ");
        for (Shape shape : shapes) {
            sumPerimeter += shape.getPerimeter();
        }
        System.out.println(sumPerimeter);
    }

    void calculateTotalSumSurface() {
        System.out.println("Total Surface sum is ");
        for (Shape shape : shapes
        ) {
            sumSurface += shape.getSurface();
        }
        System.out.println(sumSurface);
    }


}
