package homeworks.test;

public class Square implements Shape{
    private double lat;

    public Square(double lat) {
        this.lat = lat;
    }

    private double perimeter;
    private double surface;


    public double getPerimeter() {
        return lat*4;
    }


    public double getSurface() {
        return lat*lat;
    }

    @Override
    public void printPerimeter() {
        System.out.println("Perimeter is " + getPerimeter());

    }

    @Override
    public void printSurface() {
        System.out.println("Surface is " + getSurface());

    }

    @Override
    public void draw() {
        System.out.println("Drawing Square with Surface: " + getSurface() + " and Perimeter: " + getPerimeter());

    }
}
