package tema14;

public class Sportsman implements Comparable<Sportsman> {
    Integer athleteNumber;
    String AthleteName;
    String countryCode;
    String skiTimeResults; //timpul din file in format string
    String firstShootingRange;
    String secondShootingRange;
    String thirdShootingRange;
    Integer finalTimeResult; //timpul in secunde pentru operratii
    String time;   //timpul final in format string pentru afisare
    public Sportsman(Integer athleteNumber, String athleteName, String countryCode, String skiTimeResults, String firstShootingRange, String secondShootingRange, String thirdShootingRange) {
        this.athleteNumber = athleteNumber;
        AthleteName = athleteName;
        this.countryCode = countryCode;
        this.skiTimeResults = skiTimeResults;
        this.firstShootingRange = firstShootingRange;
        this.secondShootingRange = secondShootingRange;
        this.thirdShootingRange = thirdShootingRange;
        this.finalTimeResult = 0;
    }

    public void setFinalTimeResult(Integer finalTimeResult) {
        this.finalTimeResult = finalTimeResult;
    }

    @Override
    public String toString() {
        return AthleteName+" - "+ time+ "(Initial time without shooting: "+skiTimeResults+")";
    }

    public String getSkiTimeResults() {
        return skiTimeResults;
    }

    public String getFirstShootingRange() {
        return firstShootingRange;
    }

    public String getSecondShootingRange() {
        return secondShootingRange;
    }

    public String getThirdShootingRange() {
        return thirdShootingRange;
    }

    public Integer getFinalTimeResult() {
        return finalTimeResult;
    }

    public static int checkShootingResults(String str) {
       int res=0;
       for(int i=0;i<str.length();i++){
           if(str.charAt(i)=='o')
               res+=10;
       }
           return res;
       }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public int compareTo(Sportsman o) {
        return this.getFinalTimeResult()-o.getFinalTimeResult();
    }
}

