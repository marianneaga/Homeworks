package tema14;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        String fileName = "C:\\Users\\Marian\\IdeaProjects\\MyProject\\src\\tema14\\data.csv";
        File file=new File(fileName);
        List<Sportsman> list=new ArrayList<>();
        Scanner is = new Scanner(file);
            while (is.hasNext()) {
                String str = is.next();
                String [] spr=str.split(",");
                Sportsman athlete=new Sportsman(Integer.parseInt(spr[0]),spr[1],spr[2],spr[3],
                        spr[4], spr[5], spr[6]);
                int result;
                String[] timeRes =athlete.getSkiTimeResults().split(":");
                result=Integer.parseInt(timeRes[0])*60+Integer.parseInt(timeRes[1]);
                //System.out.println(result+"**");
                result+=Sportsman.checkShootingResults(athlete.getFirstShootingRange());
                result+=Sportsman.checkShootingResults(athlete.getFirstShootingRange());
                result+=Sportsman.checkShootingResults(athlete.getFirstShootingRange());
                athlete.setFinalTimeResult(result);
                athlete.setTime(Integer.toString(athlete.getFinalTimeResult()/60)+":"+
                                Integer.toString(athlete.getFinalTimeResult()%60));
                list.add(athlete);

            }
            is.close();
        Collections.sort(list);

            System.out.println("Winner: "+list.get(0).toString());
        System.out.println("Runner up: "+list.get(1).toString());
        System.out.println("Third place: "+list.get(2).toString());




    }
}