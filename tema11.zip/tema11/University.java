package homeworks.tema11;

public interface University {



    void defineFaculty();

    void defineProfile();

}
