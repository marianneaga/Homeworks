package homeworks.tema11;

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student("Marian", "Neaga", 8.4);
        Student student2 = new Student("Andrei", "Sirbu", 6.9);
        Professor professor1 = new Professor("Ion", "Popescu", 40, "Male");
        Professor professor2 = new Professor("Andreea", "Cojocaru", 70, "Female");
        Course anatomie = new Course();


        professor1.hireProfessor();
        System.out.println();
        professor2.hireProfessor();
        System.out.println();
        professor1.defineFaculty();
        System.out.println();
        professor2.defineProfile();



        student1.admitStudent();
        System.out.println();
        student2.admitStudent();
        System.out.println();
        student1.defineProfile();
        System.out.println();
        student2.defineFaculty();
        System.out.println();
        student1.assignCourse(anatomie);
        System.out.println();
        student2.assignCourse(anatomie);
        anatomie.addStudent(student1);
        anatomie.showStudents();
    }
}
