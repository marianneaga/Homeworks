package homeworks.tema11;

public class Professor implements University {

    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private boolean isHired ;


    public Professor(String firstName, String lastName, int age, String gender) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.isHired = false;
    }

    @Override
    public void defineProfile() {
        if (isHired == true) {
            System.out.println("Your profile is " + Student.getProfile());
        } else if (isHired == false) {
            System.out.println("You are not not hired in our University");
        }
    }

    @Override
    public void defineFaculty() {
        if (isHired == true) {
            System.out.println("Welcome to Faculty of Medicine !");
        } else if (isHired == false) {
            System.out.println("You are not hired in our University");
        }
    }

    public int getAge() {
        return age;
    }

    public void hireProfessor() {
        if ((age <= 60 && gender == "Female") || (age <= 64 || gender == "Male")) {
            isHired = true;
            System.out.println("Congrats you are hired !");
        } else {
            System.out.println("You are not hired as your age is " + getAge() + ", please enjoy your retirement");
            isHired = false;
        }


    }


}
