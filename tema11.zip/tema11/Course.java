package homeworks.tema11;

import java.util.ArrayList;
import java.util.List;

public class Course implements University {
    List<Student> students;

    public Course() {
        this.students = new ArrayList<>();
    }

    public void addStudent(Student student) {
        if (student.isAdmitted == true) {
            students.add(student);
            System.out.println("Added Student: " + student.getFirstName() + student.getLastName());
        } else {
            System.out.println("Not admitted: " + student.getFirstName() + student.getLastName());
        }
    }
    public void showStudents(){
        System.out.println("Assigned to this course: ");
        for (Student student : students) {
            System.out.println(student.getFirstName() + student.getLastName());
        }
    }

    @Override
    public void defineProfile() {
        System.out.println("Course of " + Student.getProfile());
    }

    @Override
    public void defineFaculty() {
        System.out.println("Course for Medicine Faculty");
    }
}
