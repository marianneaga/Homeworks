package homeworks.tema11;


public class Student implements University {
    private String firstName;
    private String lastName;
    private double averageMark;
    Boolean isAdmitted;

    public Student(String firstName, String lastName, double averageMark) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.averageMark = averageMark;
        this.isAdmitted = false;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public Student() {

    }


    public static String getProfile() {
        return "Dental Medicine";
    }

    public void admitStudent() {
        if (averageMark >= 7.5) {
            isAdmitted = true;
            System.out.println("Congrats you has been admitted!");
        } else if (averageMark < 7.5) {
            System.out.println("Admission rejected, your mark is less than 7.5 : " + getAverageMark());
            isAdmitted = false;
        }
    }

    public double getAverageMark() {
        return averageMark;
    }

    public void assignCourse(Course course) {
        if (isAdmitted == true) {
            System.out.println("This course has been assigned to you!");
            course.addStudent(this);
        } else if (isAdmitted == false) {
            System.out.println("No course assigned as you has not been admitted.");
            course.addStudent(this);
        }
    }

    @Override
    public void defineFaculty() {
        if (isAdmitted == true) {
            System.out.println("Welcome to Faculty of Medicine !");
        } else if (isAdmitted == false) {
            System.out.println("You are not admitted");
        }
    }

    @Override
    public void defineProfile() {
        if (isAdmitted == true) {
            System.out.println("Your profile is " + getProfile());
        } else if (isAdmitted == false) {
            System.out.println("You are not admitted");
        }
    }
}

