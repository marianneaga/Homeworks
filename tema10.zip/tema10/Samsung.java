package homeworks.tema10;

import java.util.ArrayList;
import java.util.List;

public abstract class Samsung extends Smartphone {
    public Samsung(String imei, String color, String material, int batteryLife) {
        super(imei, color, material, batteryLife);
    }
}
