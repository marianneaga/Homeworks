package homeworks.tema10;

public class AppleiPhoneXs extends Apple{
    public AppleiPhoneXs(String imei, String color, String material, int batteryLife) {
        super(imei, color, material, batteryLife);
    }
}
