package homeworks.tema10;

import java.util.ArrayList;
import java.util.List;

public abstract class Smartphone implements Phone {
    List<Contact> contacts = null;
    private int batteryLife;
    private String imei = null;
    private String color = null;
    private String material = null;
    List<Contact> callsHistory = null;

    public Smartphone(String imei, String color, String material, int batteryLife) {
        contacts = new ArrayList<>();
        this.batteryLife = batteryLife;
        this.imei = imei;
        this.color = color;
        this.material = material;
        callsHistory = new ArrayList<>();

    }

    @Override
    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    @Override
    public void listContacts() {
        for (Contact cc : contacts) {
            System.out.println(cc.firstName + " " + cc.lastName + " " + cc.number);
        }
    }

    @Override
    public void sendMessage(String message, Contact contact) {
        if (batteryLife < 1) {
            System.out.println("Low Battery: " + getBatteryLife());
        } else {
            if (message.length() > 500) {
                System.out.println("The message has more than 500 chars");
            } else {
                contact.addMessage(message);
                this.batteryLife -= 1;
            }
        }
    }

    @Override
    public void listMessages(Contact contact) {
        contact.listMessages();
    }

    @Override
    public void call(Contact contact) {
        if (batteryLife < 2) {
            System.out.println("Low Battery: " + getBatteryLife());
        } else {
            this.batteryLife -= 2;
            callsHistory.add(contact);
        }
    }

    @Override
    public void call(String number) {
        if (batteryLife < 2) {
            System.out.println("Low Battery: " + getBatteryLife());
        } else {
            this.batteryLife -= 2;
            callsHistory.add(new Contact("", "", number));
        }
    }

    public int getBatteryLife() {
        return batteryLife;
    }

    @Override
    public void listCallHistory() {
        System.out.println("Phone called: ");
        for (Contact contact : callsHistory) {
            contact.contactsData();
        }

    }
}
