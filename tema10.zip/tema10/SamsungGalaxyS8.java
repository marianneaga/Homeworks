package homeworks.tema10;

public class SamsungGalaxyS8 extends Samsung{
    public SamsungGalaxyS8(String imei, String color, String material, int batteryLife) {
        super(imei, color, material, batteryLife);
    }
}
