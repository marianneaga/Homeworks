package homeworks.tema10;


public interface Phone {


    void addContact(Contact contact);

    void listContacts();

    void sendMessage(String message, Contact contact);

    void listMessages(Contact contact);

    void call(Contact contact);

    void call(String number);

    void listCallHistory();


}
