package homeworks.tema10;

import java.util.ArrayList;
import java.util.List;

public abstract class Apple extends Smartphone {

    public Apple(String imei, String color, String material, int batteryLife) {
        super(imei, color, material, batteryLife);
    }
}
