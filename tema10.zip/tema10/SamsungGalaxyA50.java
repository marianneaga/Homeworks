package homeworks.tema10;

public class SamsungGalaxyA50 extends Samsung{
    public SamsungGalaxyA50(String imei, String color, String material, int batteryLife) {
        super(imei, color, material, batteryLife);
    }
}
