package homeworks.tema10;

public class AppleiPhone12Max extends Apple{

    public AppleiPhone12Max(String imei, String color, String material, int batteryLife) {
        super(imei, color, material, batteryLife);

    }
}
