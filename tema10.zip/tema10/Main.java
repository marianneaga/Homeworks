package homeworks.tema10;



public class Main {
    public static void main(String[] args) {

        Phone iPhone12Max = new AppleiPhone12Max("1234asd123124154", "Black", "Iron", 10);
        Phone iPhoneXs = new AppleiPhoneXs("5436534asda45","Gold", "Iron", 9);
        Phone galaxyS8 = new SamsungGalaxyS8("235rjgft8r864", "Blue", "Plastic", 6);
        Phone galaxyA50 = new SamsungGalaxyA50("5654645dsadei", "Purple", "Plastic", 8);

        Contact cc1 = new Contact("Ion", "Ciobanu", "0676845323");
        Contact cc2 = new Contact("Marian", "Neaga", "0792392138");

        iPhone12Max.sendMessage("Hello ", cc1);
        galaxyS8.call(cc2);
        galaxyS8.listCallHistory();
        iPhone12Max.listMessages(cc1);














    }
}
