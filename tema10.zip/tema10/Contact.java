package homeworks.tema10;

import java.util.ArrayList;
import java.util.List;

public class Contact {
   String firstName, lastName, number;
   List<String> messages = null;


    public Contact(String firstName, String lastName, String number) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.number = number;
        this.messages = new ArrayList<>();
    }
    void addMessage(String message){
        this.messages.add(message);
    }

    void listMessages(){
        System.out.print("Masages of the contact: " + this.firstName + " " +
                " " + this.lastName + " -> ");
       for (String msg : messages){
           System.out.print(msg + "; ");
       }
        System.out.println();
    }
    void contactsData(){
        System.out.println(firstName + " " + lastName + " " + number);
    }
}
