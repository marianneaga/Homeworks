package com.example.blog.tema21;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException {

      String fileName= args[0];
      Integer month=Integer.parseInt(args[1]);
      String outputFile=args[2];
      File file=new File(fileName);
        Scanner is = new Scanner(file);
        List<Person> list=new ArrayList<>();
        List<Person> outList=new ArrayList<>();
        while(is.hasNext()){
            String str = is.next();
            String [] spr=str.split(",");
            list.add(new Person(spr[0], spr[1], spr[2]));
        }
        for(Person person:list){
         String [] date=   person.getDate().split(":");
            if(month==Integer.parseInt(date[1])) outList.add(person);
        }
        outList = outList.stream().sorted(
                Comparator.comparing(Person::toString)).collect(Collectors.toList());
        for(Person prs:outList) {

            Files.write(Paths.get(outputFile),
                    (prs.getName()+"  "+prs.getSurname()+"\n").getBytes(), StandardOpenOption.APPEND);
        }




        is.close();


    }
}
