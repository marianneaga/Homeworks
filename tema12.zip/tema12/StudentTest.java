package tema12;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;

import java.time.LocalDate;

import static org.junit.Assert.assertEquals;

public class StudentTest {
   /* @Before
    public static void initializate(){
        StudentTool st=new StudentTool();
Student student1=new Student("Ciobanu", "Ion",
        LocalDate.of(2000,8,1),"m",123);
    }
*/

    @Test
    @DisplayName("test of deleteStudent method:")
    public  void addStudentStudent() throws StudentException {
        StudentTool st=new StudentTool();
        Student student1=new Student("Ciobanu", "Ion",
                LocalDate.of(2009,8,1),"m",123);
        Student student2=new Student("Munteanu", "Andrei",
                LocalDate.of(1899,8,1),"m",123);
        Student student3=new Student("Ioan", "Mihai",
                LocalDate.of(1999,8,1),"mal3",123);
        Student student4=new Student("", "Mihai",
                LocalDate.of(1999,8,1),"mal3",123);
        Assertions.assertThrows(StudentException.class, ()-> {st.addStudent(student1);});
        Assertions.assertThrows(StudentException.class, ()-> {st.addStudent(student2);});
        Assertions.assertThrows(StudentException.class, ()-> {st.addStudent(student3);});
        Assertions.assertThrows(StudentException.class, ()-> {st.addStudent(student4);});



    }


    @Test
    @DisplayName("test of deleteStudent method:")
    public  void checkDeleteStudent() throws StudentException {
        StudentTool st=new StudentTool();
        Student student1=new Student("Ciobanu", "Ion",
                LocalDate.of(2000,8,1),"m",123);
            st.addStudent(student1);
        Assertions.assertThrows(StudentException.class, ()-> {st.deleteStudent(12345);});
        Assertions.assertDoesNotThrow( ()-> {st.deleteStudent(123);});


    }
    @Test
    @DisplayName("test of retrieveStudents method:")
    public void checkRetrieveStudents() throws StudentException {
        StudentTool st=new StudentTool();
        Student student1=new Student("Ciobanu", "Ion",
                LocalDate.of(2000,8,1),"m",123);
        st.addStudent(student1);
        Assertions.assertThrows(StudentException.class,()->{st.retrieveStudents(-2);} );
        Assertions.assertDoesNotThrow(()->{st.retrieveStudents(3);} );
    }




}
