package tema12;

import java.time.LocalDate;
import java.util.*;

public class StudentTool {
List<Student> list;

    public StudentTool() {
        this.list = new ArrayList<>();
    }

    public  void addStudent(Student st) throws StudentException {
        if (st.dateOfBirth.getYear()<=1900 ||
                LocalDate.now().getYear()-18<st.dateOfBirth.getYear())
            throw new StudentException("student's date of birth does not correspond to" +
                    " the criteria");
        if(st.lastName == "" || st.firstName == "")
            throw new StudentException("student's first name or last name is exmpty");

        String [] genders={"m", "f","M", "F", "Male", "Female", "male", "female", "Male", "Female"};
        boolean genderFound=false;
        for(String str:genders){
            if (st.gender==str){
               genderFound=true;
            }
        }
        if(genderFound==false) throw new StudentException("gender incorrect");



        list.add(st);
    }








    public  void deleteStudent(Integer id) throws StudentException {
        if(id<0) throw new StudentException("id is negative");
        boolean idFound=false;
        for(Student st:list){
            if (st.id.equals(id)) {
                idFound = true;
            }
            if(idFound==true) break;
        }
        if(idFound==false) throw new StudentException("student with id="+id +" not found");
        list.removeIf(st -> id.equals(st.id));



    }


    public void retrieveStudents(Integer age) throws StudentException {
        if(age<0) throw new StudentException("age is negative");


        LocalDate today = LocalDate.now();
        list.removeIf(st -> today.getYear() - st.dateOfBirth.getYear() ==age &&
                today.getDayOfYear() >= st.dateOfBirth.getDayOfYear());
    }



    public void listStudents(){
        for(Student st:list){
            System.out.println(st.firstName+" "+st.lastName);
        }
    }

    }



