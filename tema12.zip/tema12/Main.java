package tema12;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Main {

    public static void main(String[] args) {
        StudentTool st=new StudentTool();
        try {
            Student student1 = new Student("aurel", "abc", LocalDate.of(2001, 2, 23), "maale", 123);
            Student student2 = new Student("aurel2", "abc2", LocalDate.of(2000, 2, 10), "male", 1234);
            Student student3 = new Student("aurel3", "abc3", LocalDate.of(2000, 8, 1), "male", 12345);
            st.addStudent(student1);
            st.addStudent(student2);
            //st.retrieveStudents(21);
            //st.retrieveStudents(10);
            st.deleteStudent(1234);
            st.deleteStudent(123);
            st.deleteStudent(333);
            st.addStudent(student1);
            st.addStudent(student2);
            st.addStudent(student3);
            st.retrieveStudents(10);
            st.retrieveStudents(21);

            st.listStudents();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


}
