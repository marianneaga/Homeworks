package tema13;

import java.util.Comparator;
import java.util.Objects;

public class Persoana {
    String name;
    int age;

    public Persoana(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Persoana{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Persoana persoana = (Persoana) o;
        return age == persoana.age && name.equals(persoana.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age);
    }
}
class SortByAge implements Comparator<Persoana> {
    // Used for sorting in ascending order of
    // roll number
    public int compare(Persoana a, Persoana b)
    {
        return a.age - b.age;
    }
}

class SortByName implements Comparator<Persoana> {

    public int compare(Persoana a, Persoana b)
    {
        return a.name.compareTo(b.name);
    }
}
