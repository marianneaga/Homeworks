package tema13;
import java.lang.*;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        TreeSet<Persoana> arr = new TreeSet<Persoana>(new SortByAge());
        arr.add(new Persoana("A", 23));
        arr.add(new Persoana("B", 22));
        arr.add(new Persoana("C", 21));
        System.out.println("Sort by age");
        for (Persoana p:arr)
            System.out.println(p);


        HashMap<Persoana, List<Hobby>> hobbiesMap = new HashMap<Persoana, List<Hobby>>();
        Persoana p1=new Persoana("A",20);
        List<Hobby> hobbiesList=new ArrayList<>();
        Hobby football=new Hobby("football", 2);
        football.addAdress("Stefan cel Mare 22");
        Hobby basketball=new Hobby("basketball", 3);
        basketball.addAdress("Ion Creanga 33");
        basketball.addAdress("Ion Creanga 34");
       hobbiesList.add(basketball);
        hobbiesList.add(football);


hobbiesMap.put(p1, hobbiesList);
for(Persoana p:hobbiesMap.keySet()) {
    String key = p.toString();
    List<Hobby> temp=hobbiesMap.get(p);
    String value="";
    for(Hobby h:temp)
        value+=h.toString();
    System.out.println(key+" are urmatoarele Hobby-uri: "+ value+'\n');


}





    }



}


