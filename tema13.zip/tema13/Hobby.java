package tema13;


import java.util.ArrayList;
import java.util.List;

public class Hobby {
    String name;
    int frequency;
    List<String> adresses;

    public Hobby(String name, int frequency) {
        this.name = name;
        this.frequency = frequency;
        this.adresses = new ArrayList<>();
    }
    public void addAdress(String adr){
        adresses.add(adr);
    }

    @Override
    public String toString() {
        return '\n'+"Hobby{" +
                "name='" + name + '\'' +
                ", frequency=" + frequency +
                ", adresses=" + adresses +
                '}';
    }
}
